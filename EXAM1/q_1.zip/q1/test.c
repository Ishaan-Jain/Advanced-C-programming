#include <stdio.h>
#include <stdlib.h>

#include "acutest.h"

// Remember that you can use TEST_TWO_FILES_EQUAL macro.

void test(void)
{
  
}

TEST_LIST = {
  {NULL, NULL}
};
