#ifndef CONCAT_STR_H
#define CONCAT_STR_H

#include <stdio.h>

void concat_str(char *filename_in, char *filename_out);

#endif
