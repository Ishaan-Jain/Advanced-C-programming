#include <stdio.h>
#include "concat_str.h"


void concat_str(char *filename_in, char *filename_out) {
  // Your code here
}
