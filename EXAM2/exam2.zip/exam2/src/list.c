#include <stdio.h>
#include <stdlib.h>

#include "list.h"

Node *alloc_node(int value)
{

}

int get_length(Node *head)
{

}

void print_list(Node *head)
{

}

Node *push_node(Node *head, Node *newNode)
{

}

Node *pop_node(Node *head)
{

}

Node *search_node(Node *head, int value)
{

}

Node *remove_nth_node(Node *head, int n)
{

}
